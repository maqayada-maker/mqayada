-- منصة مقايضة التمويل - قاعدة البيانات كاملة
DROP SCHEMA IF EXISTS public CASCADE;
CREATE SCHEMA public;

GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;
GRANT ALL ON SCHEMA public TO postgres, service_role;

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'client' CHECK (role IN ('client', 'advisor', 'admin')),
  is_verified boolean NOT NULL DEFAULT true,
  phone text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.requests (
  id bigserial PRIMARY KEY,
  tracking_number text UNIQUE NOT NULL,
  client_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  client_name text NOT NULL,
  sector text CHECK (sector IN ('government', 'semi-government', 'private')),
  employer text NOT NULL,
  current_bank text,
  age integer,
  salary numeric(12,2) NOT NULL DEFAULT 0,
  remaining_amount numeric(12,2) NOT NULL DEFAULT 0,
  monthly_payment numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open_for_offers' CHECK (
    status IN ('open_for_offers', 'awaiting_client_choice', 'awaiting_admin_approval', 'contact_released', 'closed_rejected')
  ),
  workflow_step text NOT NULL DEFAULT 'open_for_offers',
  selected_offer_id bigint,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.offers (
  id bigserial PRIMARY KEY,
  request_id bigint NOT NULL REFERENCES public.requests(id) ON DELETE CASCADE,
  advisor_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  net_finance numeric(12,2) NOT NULL DEFAULT 0,
  total_profit numeric(12,2) NOT NULL DEFAULT 0,
  total_finance numeric(12,2) NOT NULL DEFAULT 0,
  term_months integer NOT NULL DEFAULT 0,
  profit_rate numeric(6,2) NOT NULL DEFAULT 0,
  proposed_payment numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'submitted' CHECK (
    status IN ('submitted', 'revised', 'accepted_by_client', 'declined_by_client')
  ),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(request_id, advisor_id)
);

CREATE TABLE public.contact_submissions (
  id bigserial PRIMARY KEY,
  request_id bigint NOT NULL REFERENCES public.requests(id) ON DELETE CASCADE,
  offer_id bigint NOT NULL REFERENCES public.offers(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  phone text NOT NULL,
  notes text,
  status text NOT NULL DEFAULT 'pending_admin_review' CHECK (
    status IN ('pending_admin_review', 'approved', 'rejected')
  ),
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.notifications (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'general',
  title text NOT NULL,
  message text NOT NULL,
  client_phone text,
  offer_id bigint REFERENCES public.offers(id) ON DELETE SET NULL,
  request_id bigint REFERENCES public.requests(id) ON DELETE SET NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.requests
ADD CONSTRAINT requests_selected_offer_id_fkey
FOREIGN KEY (selected_offer_id) REFERENCES public.offers(id) ON DELETE SET NULL;

CREATE INDEX idx_users_role ON public.users(role);
CREATE INDEX idx_requests_client_id ON public.requests(client_id);
CREATE INDEX idx_requests_status ON public.requests(status);
CREATE INDEX idx_offers_request_id ON public.offers(request_id);
CREATE INDEX idx_offers_advisor_id ON public.offers(advisor_id);
CREATE INDEX idx_contact_submissions_request_id ON public.contact_submissions(request_id);
CREATE INDEX idx_contact_submissions_offer_id ON public.contact_submissions(offer_id);
CREATE INDEX idx_notifications_user_id ON public.notifications(user_id);

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_requests_updated_at BEFORE UPDATE ON public.requests FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_offers_updated_at BEFORE UPDATE ON public.offers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $function$
BEGIN
  INSERT INTO public.users (id, email, full_name, role, is_verified)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.user_metadata->>'full_name', 'مستخدم جديد'),
    COALESCE(NEW.user_metadata->>'role', 'client'),
    CASE WHEN COALESCE(NEW.user_metadata->>'role', 'client') = 'advisor' THEN false ELSE true END
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_submissions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications DISABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.users TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.requests TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.offers TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contact_submissions TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO anon, authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;
